package com.project.dba_delatorre_dometita_ramirez_tan

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(navController: NavController) {
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val scrollState = rememberScrollState()

    val gradient = Brush.verticalGradient(
        colors = listOf(Color(0xFFF0E1CC), Color(0xFFD18F79))
    )

    Box( // ✅ Wrap everything inside a Box
        modifier = Modifier
            .fillMaxSize()
            .background(gradient)
    ) {
        ModalNavigationDrawer(
            drawerState = drawerState,
            drawerContent = {
                SidebarDrawer(navController)
            }
        ) {
            Scaffold(
                containerColor = Color.Transparent, // ✅ Make Scaffold transparent so gradient shows through
                topBar = {
                    TopAppBar(
                        title = { Text("Overview") },
                        navigationIcon = {
                            IconButton(onClick = {
                                scope.launch { drawerState.open() }
                            }) {
                                Icon(Icons.Filled.Menu, contentDescription = "Menu")
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = Color(0xFFA26153),
                            titleContentColor = Color.White
                        )
                    )
                },
                content = { paddingValues ->
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(paddingValues)
                            .padding(16.dp)
                            .verticalScroll(scrollState)
                    ) {
                        Text("Today", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                        Spacer(modifier = Modifier.height(16.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            DashboardCard("Total Orders", "--", Color(0xFFC77F63))
                            DashboardCard("Order Received", "--", Color(0xFFC77F63))
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            DashboardCard("N/A", "--", Color(0xFFC77F63))
                            DashboardCard("N/A", "--", Color(0xFFC77F63))
                        }
                        Spacer(modifier = Modifier.height(24.dp))
                        Text("Summary", fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        SummaryItem("Total Orders", "0")
                        SummaryItem("Orders Received", "0")
                    }
                }
            )
        }
    }
}

@Composable
fun DashboardCard(title: String, value: String, bgColor: Color) {


    Card(
        modifier = Modifier
            .width(160.dp)
            .height(100.dp),
        colors = CardDefaults.cardColors(containerColor = bgColor)
    ) {
        Column(
            modifier = Modifier.padding(16.dp) ,
            verticalArrangement = Arrangement.SpaceBetween

        ) {
            Text(text = title, color = Color.White, fontSize = 14.sp)
            Text(text = value, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 22.sp)
        }
    }
}

@Composable
fun SummaryItem(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontSize = 16.sp)
        Text(text = value, fontWeight = FontWeight.Bold, fontSize = 16.sp)
    }
    Spacer(modifier = Modifier.height(8.dp))
}

@Composable
fun SidebarDrawer(navController: NavController) {
    val scrollState = rememberScrollState()
    Column(
        modifier = Modifier
            .fillMaxHeight()
            .width(280.dp)
            .background(Color(0xFFDEAA99))
            .padding(24.dp)
            .verticalScroll(scrollState),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(
            painter = painterResource(id = R.drawable.img),
            contentDescription = "Profile",
            modifier = Modifier
                .size(90.dp)
                .clip(CircleShape)
        )

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = "USER PROFILE",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = Color.Black
        )

        Spacer(modifier = Modifier.height(32.dp))

        val menuItems = listOf(
            "Overview" to Icons.Filled.Home,
            "Order Process" to Icons.Filled.ShoppingCart,
            "Inventory List" to Icons.Filled.Email,
            "Account List" to Icons.Filled.Person,
            "Sales Report" to Icons.Filled.Settings,
            "Log Out" to Icons.AutoMirrored.Filled.ExitToApp
        )

        menuItems.forEach { (title, icon) ->
            DrawerMenuItem(title, icon, navController)
        }
    }
}

@Composable
fun DrawerMenuItem(title: String, icon: ImageVector, navController: NavController) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp)
            .clickable {
                when (title) {
                    "Overview" -> navController.navigate(Routes.R_DashboardScreen.routes)
                    "Account List" -> navController.navigate(Routes.UserList.routes)
                    "Log Out" -> navController.navigate(Routes.R_Login.routes)

                }
            }
    ) {
        Icon(icon, contentDescription = title, tint = Color.Black, modifier = Modifier.size(24.dp))
        Spacer(modifier = Modifier.width(16.dp))
        Text(title, fontSize = 16.sp, color = Color.DarkGray)
    }
}
