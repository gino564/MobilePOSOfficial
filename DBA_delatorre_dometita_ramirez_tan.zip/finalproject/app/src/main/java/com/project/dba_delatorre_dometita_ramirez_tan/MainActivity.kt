package com.project.dba_delatorre_dometita_ramirez_tan

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.project.dba_delatorre_dometita_ramirez_tan.ui.theme.DBA_delatorre_dometita_ramirez_tanTheme
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val db = Database_Users.getDatabase(applicationContext)
        val userdao = db.dao_users()

        val repo = RepositoryUsers(userdao)
        val factory = viewModel_Factory(repo)
        val userViewModel = ViewModelProvider(this, factory)[ViewModel_users::class.java]
        setContent {
            val viewModel: frm_RegViewModel =  viewModel()
            val navController = rememberNavController()

            NavHost(navController = navController, startDestination = Routes.Screen1.routes) {
                composable(Routes.Screen1.routes){
                    Screen1(navController = navController , viewModel = viewModel, viewModel2 = userViewModel)
                }

                composable(Routes.UserList.routes){
                    ViewListScreen(viewModel2 = userViewModel, navController = navController)
                }
                composable(Routes.R_Login.routes){
                    Login(navController = navController)
                }
                composable(Routes.R_DashboardScreen.routes){
                    DashboardScreen(navController = navController)
                }

            }
        }
    }
}