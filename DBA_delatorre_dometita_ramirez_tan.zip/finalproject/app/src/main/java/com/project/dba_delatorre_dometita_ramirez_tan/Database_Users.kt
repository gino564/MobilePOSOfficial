package com.project.dba_delatorre_dometita_ramirez_tan

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase


@Database(entities = [Entity_Users::class], version = 1)
abstract class Database_Users:RoomDatabase() {
    abstract fun dao_users():Dao_Users

    companion object{
        @Volatile
        private var INSTANCE: Database_Users? = null

        fun  getDatabase(context: Context):Database_Users{
            return INSTANCE?: synchronized(this){
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    Database_Users::class.java,
                    "db_users"
                ).build()
                INSTANCE =instance
                instance
            }
        }
    }
}
