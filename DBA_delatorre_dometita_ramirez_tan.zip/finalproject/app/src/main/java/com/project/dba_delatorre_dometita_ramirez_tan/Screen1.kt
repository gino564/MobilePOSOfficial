package com.project.dba_delatorre_dometita_ramirez_tan

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import kotlinx.coroutines.launch

@Composable
fun Screen1(
    navController: NavController,
    viewModel: frm_RegViewModel,
    viewModel2: ViewModel_users,
    onUserSaved: () -> Unit = {}
    ){

    var dometita_lname by remember { mutableStateOf( "") }
    var dometita_fname by remember { mutableStateOf( "") }
    var dometita_mname by remember { mutableStateOf( "") }
    var dometita_username by remember { mutableStateOf( "") }
    var dometita_password by remember { mutableStateOf( "") }
    val userToEdit = viewModel2.userToEdit
    val scope = rememberCoroutineScope()
    val scrollState = rememberScrollState()
    val gradient = Brush.verticalGradient(
        colors = listOf(Color(0xFFF0E1CC), Color(0xFFD18F79))
    )
    var  showEditDialog by remember { mutableStateOf(false) }
    LaunchedEffect(userToEdit) {
        userToEdit?.let { user ->
            viewModel.txtlnameData(user.Entity_lname)
            viewModel.txtfnameData(user.Entity_fname)
            viewModel.txtmnameData(user.Entity_mname)
            viewModel.txtusernameData(user.Entity_username)
            viewModel.txtpasswordData(user.Entity_password)

        }
    }

    Column(
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.fillMaxSize()
            .background(gradient)
            .verticalScroll(scrollState)
    ){
        Image(
            painter = painterResource(id = R.drawable.img),
            contentDescription = "Logo",
            modifier = Modifier
                .width(150.dp)
                .height(150.dp)
                .padding(bottom = 1.dp),
            contentScale = ContentScale.Fit
        )
        Text(
            text = "Registration\nForm",
            color = Color.Black,
            fontSize = 30.sp,
            textAlign = TextAlign.Center,
            fontWeight = FontWeight.ExtraBold,
            fontFamily = FontFamily.Monospace,
        )
        OutlinedTextField(
            value = viewModel.dometita_lname,
            onValueChange = { viewModel.txtlnameData(it)},
            label = { Text(text = "Enter your last name.") },
            textStyle = TextStyle(
                color = if (dometita_lname.isNotEmpty()) Color.White else Color.Black
            )
        )

        OutlinedTextField(
            value = viewModel.dometita_fname,
            onValueChange = {viewModel.txtfnameData(it)},
            label = { Text(text = "Enter your first name.")},
            textStyle = TextStyle(
                color = if (dometita_fname.isNotEmpty()) Color.White else Color.Black
            )
        )
        OutlinedTextField(
            value = viewModel.dometita_mname,
            onValueChange = {viewModel.txtmnameData(it)},
            label = { Text(text = "Enter your middle name.")},
            textStyle = TextStyle(
                color = if (dometita_mname.isNotEmpty()) Color.White else Color.Black
            )
        )
        OutlinedTextField(
            value = viewModel.dometita_username,
            onValueChange = {viewModel.txtusernameData(it)},
            label = { Text(text = "Enter your username.")},
            textStyle = TextStyle(
                color = if (dometita_username.isNotEmpty()) Color.White else Color.Black
            )
        )
        OutlinedTextField(
            value = viewModel.dometita_password,
            onValueChange = {viewModel.txtpasswordData(it)},
            label = { Text(text = "Enter your password.")},
            textStyle = TextStyle(
                color = if (dometita_password.isNotEmpty()) Color.White else Color.Black
            ),
            visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation() // mask password input
        )



        Button(
            onClick = {
                val user = if(userToEdit!=null) {
                    userToEdit.copy(
                        Entity_fname = viewModel.dometita_fname.trim(),
                        Entity_mname = viewModel.dometita_mname.trim(),
                        Entity_lname = viewModel.dometita_lname.trim(),
                        Entity_username = viewModel.dometita_username.trim(),
                        Entity_password = viewModel.dometita_password.trim()
                    )
                }else{
                    Entity_Users(
                        Entity_fname = viewModel.dometita_fname.trim(),
                        Entity_mname = viewModel.dometita_mname.trim(),
                        Entity_lname = viewModel.dometita_lname.trim(),
                        Entity_username = viewModel.dometita_username.trim(),
                        Entity_password = viewModel.dometita_password.trim()
                            )
                }
                scope.launch {
                    if(userToEdit!= null) {
                        viewModel2.viewModel_update(user)
                    }else{
                        viewModel2.viewModel_insert(user)
                    }
                    viewModel2.viewModel_userToEdit(null)
                    showEditDialog = true
                    onUserSaved()
                }
            },
            colors = ButtonDefaults.outlinedButtonColors(
                containerColor = Color.Black,
                contentColor = Color.White

            ),
            modifier = Modifier
                .width(280.dp)
                .height(50.dp)
                .padding(5.dp)) {
            Text("Save Data")
        }

        if (showEditDialog){
            AlertDialog(
                onDismissRequest = {showEditDialog = false},
                confirmButton = {
                    Button(onClick = {
                        showEditDialog = false
                        navController.navigate(Routes.R_Login.routes)
                    },
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = Color.Black,
                            contentColor = Color.White
                        )
                            ) {
                        Text("Okay")
                    }
                },
                title = {Text("Success")},
                text = { Text("User data has been saved successfully.") }

            )
        }
    }
}